<template>

    <div id="list_admin">

        <h1>אופס - דף לא נמצא !</h1>


    </div>
</template>
<script>
    export default {


        computed: {

            uc() {

                return this.$route.query.uc;
            }

        }
    }
</script>