            export
            default {
                name: 'he',
                alpha: (e) => 'יש להזין מחרוזת בלבד בשדה ',
                numeric: (e) => 'יש להזין ספרות בלבד ',
                required: (e) => 'יש להזין ערך בשדה זה ',
            }