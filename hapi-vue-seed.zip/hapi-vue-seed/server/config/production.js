let fs = require("fs");
module.exports = {
  db: {
    storage: process.cwd() + "/db/app.db"
  },
  port: 4000,
  host: "hostname",
}
