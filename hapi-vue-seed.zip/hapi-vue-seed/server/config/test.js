module.exports = {
  host: 'localhost',
  db: {
    user: 'HEALTHQA',
    password: 'HEALTHQA',
    connectString: '10.21.100.197:1521/PDB_CEBTEST01'
  }
}