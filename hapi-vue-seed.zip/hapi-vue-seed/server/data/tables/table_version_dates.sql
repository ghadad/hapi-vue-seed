create table apps_table_version_dates ( 
    table_name  varchar2(100) , 
    Create_field varchar2(100) , 
    Update_field varchar2(100) , 
    Expired_field varchar2(100) , 
    Effective_field varchar2(100) 
)

