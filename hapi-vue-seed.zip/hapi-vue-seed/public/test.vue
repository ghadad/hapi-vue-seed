<template>
<div> bra {{msg}} </div>
</template>
<script>
 export default { 
 data : function() { 
	return { msg : "12345" }
 }
}
</script>
<style>
</style>
