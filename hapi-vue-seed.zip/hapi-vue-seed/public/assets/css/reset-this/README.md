# resetCss
CSS stylesheet to reset element style to default based on webkit css user-agent value.

#Basic usage
To reset the style of an element, link the stylesheet (reset-this.css) in your page then add the class "reset-this" to the element you want to reset.
You should notice that children of this element will also be reset.
P.S. : Pay attention to css specifity as well.

#Userfull link
http://stackoverflow.com/questions/15901030/reset-remove-css-styles-for-element-only
<br>
http://trac.webkit.org/browser/trunk/Source/WebCore/css/html.css
<br>
http://stackoverflow.com/questions/6867254/browsers-default-css-for-html-elements/6867287#6867287
<br>
https://css-tricks.com/specifics-on-css-specificity/
<br>
http://trac.webkit.org/browser/trunk/Source/WebCore/css/html.css
