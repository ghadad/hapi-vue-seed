exports.register = function (server, options, next) {
    next();
};

exports.register.attributes2 = {
	actung:"Baby"
};
exports.register.attributes = {
    pkg: { aa:2 }
};
