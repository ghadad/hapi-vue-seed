var redis = require('redis');
var client = redis.createClient(); //creates a new client
